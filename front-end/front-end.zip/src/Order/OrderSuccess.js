export default function OrderSuccess() {
    return (
        <div>
            <h1>Payment success.</h1>
            <p>Thanks for your purchase.</p>
        </div>
    )
}